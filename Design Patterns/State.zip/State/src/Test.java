/**
 * @author Nitinkumar Gove
 */
public class Test {
	
	public static void main(String a[]){
		// test1();
		// test2();
		test3();
	}
	
	public static void test1(){
		
		Switch s1 = new Switch();
		s1.pressButton();
		s1.pressButton();
		
	}
	
	public static void test2(){
		Switch s1 = new Switch();
		s1.pressButton();
		s1.pressButton();
		s1.pressButton();
	}
	
	public static void test3(){
		Switch s1 = new Switch();
		s1.pressButton();				
	}

}
