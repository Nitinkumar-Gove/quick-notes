/**
 * This is a simple state interface.
 * @author Nitinkumar Gove
 */
public interface State {
	public void pressButton();
}
